for FILE in *.txt
do
	echo $FILE
	diff $FILE ../example_results/$FILE
done

for FILE in *.mask
do
	echo $FILE
	diff $FILE ../example_results/$FILE
done

